package com.example.springboot.exception;

public class ReceptionistNotFoundException extends Exception{

	public ReceptionistNotFoundException(String msg) {
		super(msg);
	}
}
