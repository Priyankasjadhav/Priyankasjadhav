package com.example.springboot.exception;

public class IdMismatchException extends Exception {
	
	public IdMismatchException(String msg) {
		super(msg);
	}

}
