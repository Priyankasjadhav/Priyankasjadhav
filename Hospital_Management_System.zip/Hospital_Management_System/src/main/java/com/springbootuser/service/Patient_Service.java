package com.springbootuser.service;

import java.util.List;

import com.springbootuser.model.Patient;

public interface Patient_Service {
	Patient getPatients(int id);
	Patient save(Patient patient);
	void delete(int id);
	List<Patient> findAllPatients();


}
