package com.springbootuser.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootuser.model.Medicine;
import com.springbootuser.repository.Medicine_Repository;
@Service
public class Medicine_Service_IMPL implements Medicine_Service{
	@Autowired
	private Medicine_Repository medicinerepository;
	public Medicine_Service_IMPL(@Autowired Medicine_Repository medicinerepository) {
		this.medicinerepository=medicinerepository;
	}

	@Override
	public Medicine getMedicines(int id) {
		// TODO Auto-generated method stub
		Optional<Medicine> medicine=medicinerepository.findById(id);
		return medicine.orElse(null);
	}

	@Override
	public Medicine save(Medicine medicine) {
		// TODO Auto-generated method stub
		return medicinerepository.save(medicine);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		medicinerepository.deleteById(id);
		
	}

	@Override
	public List<Medicine> findAllMedicines() {
		// TODO Auto-generated method stub
		return medicinerepository.findAll();
	}

	
}
