package com.springbootuser.service;

import java.util.List;

import com.springbootuser.model.Medicine;

public interface Medicine_Service {
	Medicine getMedicines(int id);
	Medicine save(Medicine medicine);
	void delete(int id);
	List<Medicine> findAllMedicines();
	

}
