package com.springbootuser.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootuser.model.Doctor;
import com.springbootuser.model.Medicine;
import com.springbootuser.repository.Doctor_Login_Repository;
@Service
public class Doctor_Servie_IMPL implements Doctor_Service{
	@Autowired
	private Doctor_Login_Repository doctorlogin;
	
	public Doctor_Servie_IMPL(@Autowired Doctor_Login_Repository doctorlogin) {
		this.doctorlogin=doctorlogin;
	}

	@Override
	public Doctor getDoctor(Integer doctorId) {
		// TODO Auto-generated method stub
		Optional<Doctor>doctor=doctorlogin.findById(doctorId);
		return (Doctor) doctorlogin;
	}

	@Override
	public Doctor save(Doctor doctor) {
		// TODO Auto-generated method stub
		return doctorlogin.save(doctor);
	}

	@Override
	public void delete(Integer doctorId ) {
		// TODO Auto-generated method stub
		doctorlogin.deleteById(doctorId);
		
	}

	@Override
	public List<Doctor> findAllDoctors() {
		// TODO Auto-generated method stub
		return doctorlogin.findAll();
		
	}

	
	

	
	

	
}
