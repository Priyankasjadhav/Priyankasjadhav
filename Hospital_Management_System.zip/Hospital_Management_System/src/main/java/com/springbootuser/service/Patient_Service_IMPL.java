package com.springbootuser.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootuser.model.Patient;
import com.springbootuser.repository.Patient_Repository;

@Service
public class Patient_Service_IMPL implements Patient_Service{
	@Autowired
	private Patient_Repository patientrepository;
	public Patient_Service_IMPL(@Autowired Patient_Repository patientrepository) {
		this.patientrepository=patientrepository;
	}

	@Override
	public Patient getPatients(int id) {
		// TODO Auto-generated method stub
		Optional<Patient> patient=patientrepository.findById(id);
		return patient.orElse(null);
	}

	@Override
	public Patient save(Patient patient) {
		// TODO Auto-generated method stub
		return patientrepository.save(patient);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		patientrepository.deleteById(id);
		
	}

	@Override
	public List<Patient> findAllPatients() {
		// TODO Auto-generated method stub
		return patientrepository.findAll();
	}

}
