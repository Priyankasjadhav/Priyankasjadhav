package com.springbootuser.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootuser.model.Admin;
import com.springbootuser.repository.Admin_Login_Repository;
@Service
public class Admin_Service_IMPL implements Admin_Service{
	@Autowired
	private Admin_Login_Repository adminlogin;
	public Admin_Service_IMPL(@Autowired Admin_Login_Repository adminlogin) {
		this.adminlogin=adminlogin;
	}

	@Override
	public Admin getAdmin(int id) {
		// TODO Auto-generated method stub
		Optional<Admin> admin=adminlogin.findById(id);
		return admin.orElse(null);
	}

	@Override
	public Admin save(Admin admin) {
		// TODO Auto-generated method stub
		return adminlogin.save(admin);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		adminlogin.deleteById(id);
		
	}

	@Override
	public List<Admin> findAllAdmins() {
		// TODO Auto-generated method stub
		return adminlogin.findAll();
	}

	

}
