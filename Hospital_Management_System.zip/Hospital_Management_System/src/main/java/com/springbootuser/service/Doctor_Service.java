package com.springbootuser.service;

import java.util.List;

import com.springbootuser.model.Doctor;


public interface Doctor_Service {
	Doctor getDoctor(Integer doctorId);
	Doctor save(Doctor doctor);
	void delete(Integer doctorId);
	List<Doctor> findAllDoctors();
	
}
