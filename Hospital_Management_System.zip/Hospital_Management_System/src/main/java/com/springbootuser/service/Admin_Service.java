package com.springbootuser.service;

import java.util.List;

import com.springbootuser.model.Admin;

public interface Admin_Service {
	Admin getAdmin(int id);
	Admin save(Admin admin);
	void delete(int id);
	List<Admin> findAllAdmins();
	
	

}
