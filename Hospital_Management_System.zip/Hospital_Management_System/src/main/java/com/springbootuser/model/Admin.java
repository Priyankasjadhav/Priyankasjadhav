package com.springbootuser.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String city;
	private String email;
	private String password;
	private String fullname;
	private long mobile;
	private int pincode;
	
	
	public Admin() {
		super();
	}


	public Admin(String city, String email, String password, String fullname, long mobile, int pincode) {
		super();
		this.city = city;
		this.email = email;
		this.password = password;
		this.fullname = fullname;
		this.mobile = mobile;
		this.pincode = pincode;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getFullname() {
		return fullname;
	}


	public void setFullname(String fullname) {
		this.fullname = fullname;
	}


	public long getMobile() {
		return mobile;
	}


	public void setMobile(long mobile) {
		this.mobile = mobile;
	}


	public int getPincode() {
		return pincode;
	}


	public void setPincode(int pincode) {
		this.pincode = pincode;
	}


	@Override
	public String toString() {
		return "admin [id=" + id + ", city=" + city + ", email=" + email + ", password=" + password + ", fullname="
				+ fullname + ", mobile=" + mobile + ", pincode=" + pincode + "]";
	}	

}
