package com.springbootuser.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int patientId;
	private String patientName;
	private int patientAge;
	private String patientCity;
	private long patientMobileNumber;

	// No arguement constructor
	@ManyToOne
	@JoinColumn(name = "doctorId")
	private Doctor doctor;

	public Patient() {
		super();
	}

	public Patient(String patientName, int patientAge, String patientCity, long patientMobileNumber, Doctor doctor) {
		super();
		this.patientName = patientName;
		this.patientAge = patientAge;
		this.patientCity = patientCity;
		this.patientMobileNumber = patientMobileNumber;
		this.doctor = doctor;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	

	// Getters and setters
	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getPatientAge() {
		return patientAge;
	}

	public void setPatientAge(int patientAge) {
		this.patientAge = patientAge;
	}

	public String getPatientCity() {
		return patientCity;
	}

	public void setPatientCity(String patientCity) {
		this.patientCity = patientCity;
	}

	public long getPatientMobileNumber() {
		return patientMobileNumber;
	}

	public void setPatientMobileNumber(long patientMobileNumber) {
		this.patientMobileNumber = patientMobileNumber;
	}

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", patientAge=" + patientAge
				+ ", patientCity=" + patientCity + ", patientMobileNumber=" + patientMobileNumber + ", doctor=" + doctor
				+ "]";
	}
}
	// To string method
	
	
