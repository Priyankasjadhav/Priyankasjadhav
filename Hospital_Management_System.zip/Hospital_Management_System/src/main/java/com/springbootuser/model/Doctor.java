package com.springbootuser.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.OneToMany;

@Entity
public class Doctor{
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int doctorId;
		private String doctorName;
		private String email;
		private int age;
		private long mobile;
		
		@OneToMany(mappedBy = "doctor", cascade=CascadeType.ALL)
		private List<Patient> patients;
		

		public Doctor() {
			super();
		}
		
		public Doctor(String doctorName, String email, int age, long mobile, List<Patient> patients) {
			super();
			this.doctorName = doctorName;
			this.email = email;
			this.age = age;
			this.mobile = mobile;
			this.patients = patients;
		}
		
		public List<Patient> getPatients() {
			return patients;
		}


		
		
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public int getAge() {
			return age;
		}
		


		public void setAge(int age) {
			this.age = age;
		}
		public long getMobile() {
			return mobile;
		}
		public int getDoctorId() {
			return doctorId;
		}

		public void setDoctorId(int doctorId) {
			this.doctorId = doctorId;
		}

		public String getDoctorName() {
			return doctorName;
		}

		public void setDoctorName(String doctorName) {
			this.doctorName = doctorName;
		}

		public void setMobile(long mobile) {
			this.mobile = mobile;
		}

		@Override
		public String toString() {
			return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", email=" + email + ", age=" + age
					+ ", mobile=" + mobile + ", patients=" + patients + "]";
		}
		
		
		
		
	

}
