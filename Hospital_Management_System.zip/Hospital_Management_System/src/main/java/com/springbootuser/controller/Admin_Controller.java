package com.springbootuser.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springbootuser.model.Admin;
import com.springbootuser.service.Admin_Service;

@CrossOrigin("*")
@RestController
public class Admin_Controller {
	@Autowired
	private Admin_Service admin_service;
	
	public Admin_Controller(@Autowired Admin_Service admin_service) {
		this.admin_service=admin_service;
	}
	@GetMapping("/admin/{adminId}")
	public Admin getPatients(@PathVariable  int id) {
		// TODO Auto-generated method stub
		return admin_service.getAdmin(id);
	}
	@GetMapping("/admin")
	public List<Admin>getallPatients() {
		return admin_service.findAllAdmins();
	}
	
	@PostMapping("/admin")
	public Admin newAdmin(@RequestBody  Admin admin) {
		// TODO Auto-generated method stub
		return admin_service.save(admin);
    }
	
	@PutMapping("/admin")
	public Admin updateAdmin(@RequestBody  Admin admin) {
		// TODO Auto-generated method stub
		return admin_service.save(admin);
	}
	
	@DeleteMapping("/admin/{id}")
	public void deleteAdmin(@PathVariable  int id) {
		// TODO Auto-generated method stub
		admin_service.delete(id);
	}

}
