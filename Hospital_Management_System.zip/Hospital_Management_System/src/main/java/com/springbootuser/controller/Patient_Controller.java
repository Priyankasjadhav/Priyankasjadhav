package com.springbootuser.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springbootuser.model.Patient;
import com.springbootuser.service.Patient_Service;


@CrossOrigin("*")
@RestController
public class Patient_Controller {
	@Autowired
	private Patient_Service patient_service;
	
	public Patient_Controller(@Autowired Patient_Service patient_service) {
		this.patient_service=patient_service;
	}
	@GetMapping("/patient/{patientId}")
	public Patient getPatients(@PathVariable  int patientId) {
		// TODO Auto-generated method stub
		return patient_service.getPatients(patientId);
	}
	@GetMapping("/patient")
	public List<Patient>getallPatients() {
		return patient_service.findAllPatients();
	}
	
	@PostMapping("/patient")
	public Patient newPatient(@RequestBody  Patient patient) {
		// TODO Auto-generated method stub
		return patient_service.save(patient);
    }
	
	@PutMapping("/patient")
	public Patient updatePatient(@RequestBody  Patient patient) {
		// TODO Auto-generated method stub
		return patient_service.save(patient);
	}
	
	@DeleteMapping("/patient/{id}")
	public void deletePatients(@PathVariable  int patientId) {
		// TODO Auto-generated method stub
		patient_service.delete(patientId);
	}
	

}
