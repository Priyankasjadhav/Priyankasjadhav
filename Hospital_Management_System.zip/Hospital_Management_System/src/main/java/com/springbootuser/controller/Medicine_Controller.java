package com.springbootuser.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springbootuser.model.Medicine;
import com.springbootuser.service.Medicine_Service;

@RestController
@CrossOrigin("*")
public class Medicine_Controller {
	@Autowired
	private Medicine_Service medicine_service;
	
	public Medicine_Controller(@Autowired Medicine_Service medicine_service) {
		this.medicine_service=medicine_service;
	}
	@GetMapping("/medicine/{medicineId}")
	public Medicine getPatients(@PathVariable  int id) {
		// TODO Auto-generated method stub
		return medicine_service.getMedicines(id);
	}
	@GetMapping("/medicine")
	public List<Medicine> getMedicines() {
		return medicine_service.findAllMedicines();
	}
	
	@PostMapping("/medicine")
	public Medicine newMedicine(@RequestBody  Medicine medicine) {
		// TODO Auto-generated method stub
		return medicine_service.save(medicine);
    }
	
	@PutMapping("/medicine")
	public Medicine updateMedicine(@RequestBody  Medicine medicine) {
		// TODO Auto-generated method stub
		return medicine_service.save(medicine);
	}
	
	@DeleteMapping("/medicine/{id}")
	public void deleteMedicines(@PathVariable  int id) {
		// TODO Auto-generated method stub
		medicine_service.delete(id);
	}

}
