package com.springbootuser.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springbootuser.model.Doctor;
import com.springbootuser.service.Doctor_Service;

@RestController
@CrossOrigin("*")
public class Doctor_Controller {
	@Autowired
	private Doctor_Service doctor_service;
	
	public Doctor_Controller(@Autowired Doctor_Service doctor_service) {
		this.doctor_service=doctor_service;
	}
	@GetMapping("/doctor/{doctorId}")
	public Doctor getDoctor(@PathVariable  Integer doctorId) {
		// TODO Auto-generated method stub
		return doctor_service.getDoctor(doctorId);
	}
	@GetMapping("/doctor")
	public List<Doctor>getallDoctors() {
		return doctor_service.findAllDoctors();
	}
	
	@PostMapping("/doctor")
	public Doctor newPatient(@RequestBody  Doctor doctor) {
		// TODO Auto-generated method stub
		return doctor_service.save(doctor);
    }
	
	@PutMapping("/doctor")
	public Doctor updateDoctor(@RequestBody  Doctor doctor) {
		// TODO Auto-generated method stub
		return doctor_service.save(doctor);
	}
	
	@DeleteMapping("/doctor/{doctorId}")
	public void deletePatients(@PathVariable  Integer doctorId) {
		// TODO Auto-generated method stub
		doctor_service.delete(doctorId);
	}

}
