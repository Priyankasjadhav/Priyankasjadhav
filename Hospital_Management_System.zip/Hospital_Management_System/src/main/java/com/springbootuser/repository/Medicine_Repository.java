package com.springbootuser.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springbootuser.model.Medicine;

public interface Medicine_Repository extends JpaRepository <Medicine, Integer>{

}
