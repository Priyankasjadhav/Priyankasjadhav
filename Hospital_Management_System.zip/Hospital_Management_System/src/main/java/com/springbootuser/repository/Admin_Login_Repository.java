package com.springbootuser.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springbootuser.model.Admin;

public interface Admin_Login_Repository extends JpaRepository <Admin, Integer> {
	
	
}
