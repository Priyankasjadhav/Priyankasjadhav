package com.springbootuser.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springbootuser.model.Patient;

public interface Patient_Repository extends JpaRepository <Patient , Integer>{

}
