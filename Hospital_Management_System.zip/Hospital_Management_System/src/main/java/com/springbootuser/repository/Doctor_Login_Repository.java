package com.springbootuser.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springbootuser.model.Doctor;

public interface Doctor_Login_Repository extends JpaRepository<Doctor , Integer>{




}
